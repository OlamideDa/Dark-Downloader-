import os
import requests
from bs4 import BeautifulSoup
import yt_dlp
from flask import Flask, request, send_file, render_template

app = Flask(__name__)
DOWNLOAD_FOLDER = "downloads"
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

def detect_platform(url):
    url_lower = url.lower()
    if "tiktok.com" in url_lower:
        return "tiktok"
    elif "facebook.com" in url_lower or "fb.watch" in url_lower:
        return "facebook"
    elif "instagram.com" in url_lower:
        return "instagram"
    return None

def download_tiktok(url):
    ydl_opts = {
        'outtmpl': f'{DOWNLOAD_FOLDER}/%(title)s.%(ext)s',
        'quiet': True,
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        return f"{info['title']}.mp4"

def download_facebook(url):
    headers = {"User-Agent": "Mozilla/5.0"}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, 'html.parser')
    video_tag = soup.find("video")
    if video_tag:
        video_url = video_tag.get("src")
        if video_url:
            filename = os.path.join(DOWNLOAD_FOLDER, "facebook_video.mp4")
            with open(filename, "wb") as f:
                f.write(requests.get(video_url).content)
            return filename
    return None

def download_instagram(url):
    headers = {"User-Agent": "Mozilla/5.0"}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, 'html.parser')
    meta_tag = soup.find("meta", property="og:video")
    if meta_tag:
        video_url = meta_tag.get("content")
        if video_url:
            filename = os.path.join(DOWNLOAD_FOLDER, "instagram_video.mp4")
            with open(filename, "wb") as f:
                f.write(requests.get(video_url).content)
            return filename
    return None

@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        url = request.form.get("url")
        platform = detect_platform(url)
        if platform == "tiktok":
            filename = download_tiktok(url)
            return send_file(os.path.join(DOWNLOAD_FOLDER, filename), as_attachment=True)
        elif platform == "facebook":
            filename = download_facebook(url)
            if filename:
                return send_file(filename, as_attachment=True)
        elif platform == "instagram":
            filename = download_instagram(url)
            if filename:
                return send_file(filename, as_attachment=True)
        return "Failed to download. Unsupported platform or private content."
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
